# Coding Prompt — ComicCraft

Build and maintain **ComicCraft — AI Comic Story Creator** as a production-quality beginner-friendly FastAPI application.

## Goal
Create a web app that transforms a user's story idea into a multi-panel comic. Inputs: story prompt, main character name, setting, story tone, art style, and panel count. Outputs: structured panel outline, narration/dialogue, illustration for each panel, browser preview, and downloadable PDF.

## Required architecture
- `app/main.py`: FastAPI application, static files, templates, routes.
- `app/routes.py`: HTTP endpoints and orchestration.
- `app/models.py`: Pydantic request/response models.
- `app/config.py`: environment configuration.
- `app/services/gemini.py`: outline and story generation.
- `app/services/image_generator.py`: illustration generation with safe local fallback.
- `app/services/layout_builder.py`: final panel layout objects.
- `app/services/exporters.py`: PDF generation.
- `templates/index.html`: input form.
- `templates/comic_preview.html`: panel-by-panel preview.
- `templates/export_success.html`: export confirmation.
- `static/panels`: generated panel images.
- `static/exports`: generated PDFs.
- `tests/test_app.py`: smoke/integration tests.

## Functional requirements
1. GET `/` renders the form.
2. POST `/generate` accepts HTML form fields and renders the comic preview.
3. POST `/generate-comic/json` accepts JSON and returns `success`, `layout`, and `pdf_path`.
4. GET `/test-image` generates one test image.
5. GET `/export-success` renders an export confirmation page.
6. GET `/health` returns a simple service-health JSON response.
7. All AI calls must have deterministic local fallbacks so the application can run without API credentials.
8. Do not hard-code secrets.
9. Validate inputs with Pydantic and enforce a reasonable panel limit.
10. Keep generated files out of Git.
11. PDF export must work with locally generated images.
12. Never leave imports, routes, template variables, directories, or dependencies unresolved.

## AI behavior
Use Gemini for structured story generation when credentials are available. Request JSON-only structured output and validate it. For images, use a configurable Hugging Face endpoint when available; otherwise create a local placeholder image so the end-to-end workflow remains testable.

## Reliability requirements
Before declaring the task complete:
- install `requirements.txt` in a clean virtual environment;
- run `pytest`;
- start Uvicorn;
- verify `/health`, `/`, and `/generate-comic/json`;
- verify a PDF is created;
- verify generated image files exist;
- fix every import, syntax, dependency, template, and path error found during testing.
