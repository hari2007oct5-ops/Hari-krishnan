from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    r = client.get('/health')
    assert r.status_code == 200
    assert r.json()['status'] == 'ok'

def test_home():
    r = client.get('/')
    assert r.status_code == 200
    assert 'ComicCraft' in r.text

def test_json_generation():
    r = client.post('/generate-comic/json', json={
        'story_prompt':'A fox explores a magical forest',
        'character_name':'Foxy', 'setting':'forest', 'tone':'funny', 'art_style':'comic book', 'panels':2
    })
    assert r.status_code == 200
    data = r.json()
    assert data['success'] is True
    assert len(data['layout']) == 2
    assert data['pdf_path'].endswith('.pdf')
