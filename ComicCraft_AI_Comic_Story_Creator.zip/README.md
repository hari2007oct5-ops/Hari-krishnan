# ComicCraft — AI Comic Story Creator

A runnable FastAPI web application based on the supplied ComicCraft specification. It accepts a story prompt, character, setting, tone, art style and panel count; creates a panel outline, narration/dialogue, panel images, a preview page, and a downloadable PDF.

## Why this version is reliable

- **Demo mode is enabled by default**, so it starts without API keys, GPU, Stable Diffusion weights, or external services.
- Gemini and Hugging Face integrations are optional and fail back to local generation instead of crashing the request.
- Generated files are written to `static/panels` and `static/exports`.
- `/health` and automated tests are included.

## Windows setup

```powershell
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
copy .env.example .env
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000 and API docs at http://127.0.0.1:8000/docs.

## macOS/Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```

## Live AI mode

Put a Gemini API key in `.env` and set `DEMO_MODE=false`. Gemini is used for structured outline/story generation. If `HF_API_KEY` is also supplied, the optional Hugging Face image endpoint is used; otherwise local placeholder panel images are generated.

The original specification describes Gemini Flash for panel outlines, Gemini Pro for detailed narration/dialogue, Stable Diffusion for illustrations, FastAPI/Jinja2 for the application, and FPDF for PDF export. This implementation keeps those architectural responsibilities while using current, optional integrations and a no-key local fallback.

## API

`POST /generate` — browser form workflow.

`POST /generate-comic/json` — JSON workflow.

`GET /test-image?prompt=...` — image-generation test.

`GET /health` — health check.
