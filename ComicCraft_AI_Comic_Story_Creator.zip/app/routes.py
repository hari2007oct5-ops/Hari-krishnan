from fastapi import APIRouter, Request, Form, HTTPException
from fastapi.responses import HTMLResponse
from app.models import PromptRequest
from app.services.gemini import generate_outline, generate_story
from app.services.image_generator import generate_image
from app.services.layout_builder import build_comic_layout
from app.services.exporters import save_pdf

router = APIRouter()

@router.get("/", response_class=HTMLResponse)
async def home(request: Request):
    from app.main import templates
    return templates.TemplateResponse("index.html", {"request": request})

async def _generate(req):
    panels = generate_outline(req)
    panels = generate_story(panels, req)
    images = [generate_image(p.image_prompt, p.number) for p in panels]
    layout = build_comic_layout(panels, images)
    pdf_path = save_pdf(layout)
    return layout, pdf_path

@router.post("/generate", response_class=HTMLResponse)
async def generate(request: Request, story_prompt: str = Form(...), character_name: str = Form("Alex"), setting: str = Form("enchanted forest"), tone: str = Form("adventurous"), art_style: str = Form("comic book"), panels: int = Form(5)):
    try:
        req = PromptRequest(story_prompt=story_prompt, character_name=character_name, setting=setting, tone=tone, art_style=art_style, panels=panels)
        layout, pdf_path = await _generate(req)
        from app.main import templates
        return templates.TemplateResponse("comic_preview.html", {"request": request, "layout": layout, "pdf_path": pdf_path})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/generate-comic/json")
async def generate_json(req: PromptRequest):
    try:
        layout, pdf_path = await _generate(req)
        return {"success": True, "layout": layout, "pdf_path": pdf_path}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/export-success", response_class=HTMLResponse)
async def export_success(request: Request):
    from app.main import templates
    return templates.TemplateResponse("export_success.html", {"request": request})

@router.get("/test-image")
async def test_image(prompt: str = "a brave fox in an enchanted forest"):
    return {"image": generate_image(prompt, 0)}
