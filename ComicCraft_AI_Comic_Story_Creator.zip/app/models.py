from pydantic import BaseModel, Field

class PromptRequest(BaseModel):
    story_prompt: str = Field(min_length=3, max_length=2000)
    character_name: str = Field(default="Alex", max_length=100)
    setting: str = Field(default="enchanted forest", max_length=200)
    tone: str = Field(default="adventurous", max_length=100)
    art_style: str = Field(default="comic book", max_length=100)
    panels: int = Field(default=5, ge=1, le=8)

class Panel(BaseModel):
    number: int
    title: str
    scene_description: str
    image_prompt: str
    caption: str = ""
    narration: str = ""
    dialogue: str = ""
