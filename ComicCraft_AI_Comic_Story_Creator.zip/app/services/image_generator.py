from pathlib import Path
import io, re
from PIL import Image, ImageDraw, ImageFont
from app.config import settings

BASE = Path(__file__).resolve().parents[2]
OUT = BASE / "static" / "panels"
OUT.mkdir(parents=True, exist_ok=True)

def _safe(s):
    return re.sub(r'[^a-zA-Z0-9_-]+', '_', s)[:60]

def _demo_image(prompt, number):
    img = Image.new("RGB", (1024, 576), "white")
    d = ImageDraw.Draw(img)
    d.rectangle((20,20,1004,556), outline="black", width=8)
    d.text((45,45), f"COMIC PANEL {number}", fill="black")
    words = prompt[:220]
    d.text((45,100), words, fill="black", spacing=8)
    d.ellipse((350,250,674,574), outline="black", width=8)
    path = OUT / f"panel_{number}_{_safe(prompt)}.png"
    img.save(path)
    return f"/static/panels/{path.name}"

def generate_image(prompt, number):
    # Optional Hugging Face image generation. Demo fallback keeps local setup runnable.
    if settings.demo_mode or not settings.hf_api_key:
        return _demo_image(prompt, number)
    try:
        import requests
        url = f"https://api-inference.huggingface.co/models/{settings.hf_model}"
        r = requests.post(url, headers={"Authorization": f"Bearer {settings.hf_api_key}"}, json={"inputs": prompt}, timeout=120)
        r.raise_for_status()
        img = Image.open(io.BytesIO(r.content)).convert("RGB")
        path = OUT / f"panel_{number}_{_safe(prompt)}.png"
        img.save(path)
        return f"/static/panels/{path.name}"
    except Exception:
        return _demo_image(prompt, number)
