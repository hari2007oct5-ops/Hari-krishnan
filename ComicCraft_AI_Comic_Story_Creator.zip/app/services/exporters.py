from pathlib import Path
from fpdf import FPDF
from PIL import Image
from datetime import datetime
import textwrap

BASE = Path(__file__).resolve().parents[2]
EXPORTS = BASE / "static" / "exports"
EXPORTS.mkdir(parents=True, exist_ok=True)

def save_pdf(layout):
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    for panel in layout:
        pdf.add_page()
        pdf.set_font("Helvetica", "B", 18)
        pdf.multi_cell(0, 10, f"Panel {panel['number']}: {panel['title']}")
        img_path = BASE / panel['image'].lstrip('/').replace('static/','static/')
        if img_path.exists():
            with Image.open(img_path) as im:
                w, h = im.size
            max_w = 180
            max_h = 105
            ratio = min(max_w/w, max_h/h)
            pdf.image(str(img_path), w=w*ratio, h=h*ratio)
        pdf.ln(4)
        pdf.set_font("Helvetica", "I", 11)
        pdf.multi_cell(0, 7, panel['scene_description'])
        pdf.set_font("Helvetica", "B", 11)
        pdf.multi_cell(0, 7, panel['caption'])
        pdf.set_font("Helvetica", size=11)
        pdf.multi_cell(0, 7, panel['narration'])
        pdf.multi_cell(0, 7, panel['dialogue'])
    filename = EXPORTS / f"comic_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}.pdf"
    pdf.output(str(filename))
    return f"/static/exports/{filename.name}"
