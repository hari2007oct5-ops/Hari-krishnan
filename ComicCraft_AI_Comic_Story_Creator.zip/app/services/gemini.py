import json
from app.config import settings
from app.models import Panel


def _demo_outline(req):
    beats = [
        ("The Beginning", "The hero discovers a strange clue that starts the adventure."),
        ("A Hidden Path", "The hero follows the clue into a mysterious part of the setting."),
        ("The Challenge", "A surprising obstacle forces the hero to make a brave choice."),
        ("The Turning Point", "The hero solves the central problem using courage and creativity."),
        ("A New Dawn", "The adventure ends with a satisfying discovery and a hint of what comes next."),
    ]
    return [Panel(number=i+1, title=t, scene_description=d,
                  image_prompt=f"{req.art_style}, {req.tone}, {req.character_name} in {req.setting}; {d}; cinematic comic panel")
            for i, (t,d) in enumerate(beats[:req.panels])]


def generate_outline(req):
    if settings.demo_mode or not settings.gemini_api_key:
        return _demo_outline(req)
    try:
        from google import genai
        client = genai.Client(api_key=settings.gemini_api_key)
        prompt = f"""Create a JSON array with exactly {req.panels} comic panels. Story: {req.story_prompt}. Character: {req.character_name}. Setting: {req.setting}. Tone: {req.tone}. Art style: {req.art_style}. Each item must have number,title,scene_description,image_prompt. Return JSON only."""
        response = client.models.generate_content(model=settings.gemini_model, contents=prompt)
        data = json.loads(response.text)
        return [Panel(**x) for x in data]
    except Exception:
        return _demo_outline(req)


def generate_story(panels, req):
    if settings.demo_mode or not settings.gemini_api_key:
        for p in panels:
            p.caption = f"{p.title}: the adventure unfolds in {req.setting}."
            p.narration = f"{req.character_name} moves forward, determined to discover the truth."
            p.dialogue = f'{req.character_name}: "We can do this!"'
        return panels
    try:
        from google import genai
        client = genai.Client(api_key=settings.gemini_api_key)
        outline = [p.model_dump() for p in panels]
        prompt = f"Expand this comic outline into concise caption, narration and dialogue for every panel. Character: {req.character_name}. Return JSON array only. Outline: {json.dumps(outline)}"
        response = client.models.generate_content(model=settings.gemini_model, contents=prompt)
        data = json.loads(response.text)
        for p, x in zip(panels, data):
            p.caption, p.narration, p.dialogue = x.get('caption',''), x.get('narration',''), x.get('dialogue','')
        return panels
    except Exception:
        return _demo_story(panels, req)

def _demo_story(panels, req):
    for p in panels:
        p.caption = f"{p.title}: the adventure unfolds in {req.setting}."
        p.narration = f"{req.character_name} moves forward, determined to discover the truth."
        p.dialogue = f'{req.character_name}: "We can do this!"'
    return panels
