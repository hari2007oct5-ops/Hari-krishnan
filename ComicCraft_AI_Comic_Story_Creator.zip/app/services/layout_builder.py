def build_comic_layout(panels, image_paths):
    return [
        {"number": p.number, "title": p.title, "image": image_paths[i],
         "scene_description": p.scene_description, "caption": p.caption,
         "narration": p.narration, "dialogue": p.dialogue,
         "image_prompt": p.image_prompt}
        for i, p in enumerate(panels)
    ]
