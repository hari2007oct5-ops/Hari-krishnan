from pathlib import Path
from typing import List

from fastapi import FastAPI, Form
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
STATIC_DIR.mkdir(parents=True, exist_ok=True)

app = FastAPI(
    title="ComicCraft - AI Comic Story Creator",
    description="Create a five-panel comic story from a prompt.",
    version="1.0.0",
)

app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


class ComicRequest(BaseModel):
    story_prompt: str
    character_name: str = "Alex"
    setting: str = "A futuristic city"
    tone: str = "Adventure"
    art_style: str = "Comic book"


def generate_outline(
    story_prompt: str,
    character_name: str,
    setting: str,
    tone: str,
) -> List[dict]:
    prompt = story_prompt.strip() or "an unexpected adventure"

    return [
        {
            "panel": 1,
            "scene": f"{character_name} begins the adventure: {prompt}.",
            "narration": f"The story begins in {setting}.",
            "dialogue": f"{character_name}: Something unusual is happening!",
        },
        {
            "panel": 2,
            "scene": f"{character_name} investigates what happened.",
            "narration": "The mystery becomes more interesting.",
            "dialogue": f"{character_name}: I need to find out what is happening.",
        },
        {
            "panel": 3,
            "scene": f"{character_name} encounters the main challenge.",
            "narration": "The situation becomes more difficult.",
            "dialogue": f"{character_name}: I won't give up!",
        },
        {
            "panel": 4,
            "scene": f"{character_name} discovers a clever solution.",
            "narration": "A new idea changes everything.",
            "dialogue": f"{character_name}: I know what to do now!",
        },
        {
            "panel": 5,
            "scene": f"{character_name} successfully completes the adventure.",
            "narration": f"The {tone.lower()} adventure comes to an end.",
            "dialogue": f"{character_name}: What an adventure!",
        },
    ]


def generate_story(outline: List[dict], character_name: str) -> List[dict]:
    story = []

    for panel in outline:
        story.append(
            {
                "panel": panel["panel"],
                "scene": panel["scene"],
                "narration": panel["narration"],
                "dialogue": panel["dialogue"],
                "image_prompt": (
                    f"{panel['scene']}, featuring {character_name}, "
                    "comic book illustration, detailed characters, "
                    "cinematic composition"
                ),
            }
        )

    return story


@app.get("/", response_class=HTMLResponse)
async def home():
    return HTMLResponse(
        """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ComicCraft</title>
<style>
*{box-sizing:border-box}
body{margin:0;padding:0;font-family:Arial,Helvetica,sans-serif;background:#f4f6f8;color:#222}
.container{max-width:900px;margin:40px auto;padding:20px}
.card{background:#fff;padding:35px;border-radius:15px;box-shadow:0 5px 20px rgba(0,0,0,.10)}
h1{margin-top:0;font-size:38px}
.subtitle{color:#666;margin-bottom:30px}
label{display:block;font-weight:bold;margin-top:18px;margin-bottom:7px}
input,textarea,select{width:100%;padding:12px;border:1px solid #ccc;border-radius:7px;font-size:15px}
textarea{min-height:130px;resize:vertical}
button{margin-top:25px;padding:13px 25px;border:none;border-radius:7px;background:#222;color:#fff;font-size:16px;cursor:pointer}
button:hover{background:#444}
.links{margin-top:25px}
a{color:#222}
</style>
</head>
<body>
<div class="container">
<div class="card">
<h1>ComicCraft</h1>
<p class="subtitle">AI Comic Story Creator - Demo Mode</p>
<form method="post" action="/generate">
<label for="story_prompt">Story Prompt</label>
<textarea id="story_prompt" name="story_prompt" required>A young hero discovers a mysterious robot in a futuristic city.</textarea>
<label for="character_name">Character Name</label>
<input id="character_name" name="character_name" value="Alex">
<label for="setting">Setting</label>
<input id="setting" name="setting" value="A futuristic city">
<label for="tone">Tone</label>
<select id="tone" name="tone">
<option>Adventure</option>
<option>Funny</option>
<option>Fantasy</option>
<option>Mystery</option>
<option>Science Fiction</option>
</select>
<label for="art_style">Art Style</label>
<input id="art_style" name="art_style" value="Comic book">
<button type="submit">Generate Comic</button>
</form>
<div class="links"><a href="/docs">Open API Documentation</a></div>
</div>
</div>
</body>
</html>
"""
    )


@app.post("/generate", response_class=HTMLResponse)
async def generate(
    story_prompt: str = Form(...),
    character_name: str = Form("Alex"),
    setting: str = Form("A futuristic city"),
    tone: str = Form("Adventure"),
    art_style: str = Form("Comic book"),
):
    outline = generate_outline(story_prompt, character_name, setting, tone)
    story = generate_story(outline, character_name)

    panels_html = ""

    for panel in story:
        panels_html += f"""
<div class="panel">
<h2>Panel {panel["panel"]}</h2>
<p><strong>Scene:</strong> {panel["scene"]}</p>
<p><strong>Narration:</strong> {panel["narration"]}</p>
<p><strong>Dialogue:</strong> {panel["dialogue"]}</p>
<p><strong>Image Prompt:</strong> {panel["image_prompt"]}</p>
</div>
"""

    return HTMLResponse(
        f"""
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ComicCraft Preview</title>
<style>
body{{margin:0;padding:30px;font-family:Arial,Helvetica,sans-serif;background:#f4f6f8;color:#222}}
.container{{max-width:900px;margin:auto}}
.header{{background:#fff;padding:25px;border-radius:12px;margin-bottom:20px}}
.panel{{background:#fff;padding:25px;margin-bottom:20px;border-radius:12px;box-shadow:0 3px 12px rgba(0,0,0,.08)}}
.panel h2{{margin-top:0}}
a{{color:#222}}
.back{{display:inline-block;margin-top:10px}}
</style>
</head>
<body>
<div class="container">
<div class="header">
<h1>Comic Preview</h1>
<p><strong>Character:</strong> {character_name}</p>
<p><strong>Setting:</strong> {setting}</p>
<p><strong>Tone:</strong> {tone}</p>
<p><strong>Art Style:</strong> {art_style}</p>
</div>
{panels_html}
<a class="back" href="/">← Create Another Comic</a>
</div>
</body>
</html>
"""
    )


@app.post("/generate-comic/json")
async def generate_comic_json(data: ComicRequest):
    outline = generate_outline(
        data.story_prompt,
        data.character_name,
        data.setting,
        data.tone,
    )
    story = generate_story(outline, data.character_name)

    return {
        "success": True,
        "mode": "demo",
        "art_style": data.art_style,
        "panels": story,
    }


@app.get("/test-image")
async def test_image():
    return {
        "success": True,
        "message": "Demo image endpoint is working.",
    }


@app.get("/export-success", response_class=HTMLResponse)
async def export_success():
    return HTMLResponse(
        """
<!DOCTYPE html>
<html>
<head><title>Export Success</title></head>
<body style="font-family:Arial;padding:40px;text-align:center">
<h1>Export Successful</h1>
<p>ComicCraft is working correctly.</p>
<p><a href="/">Back to ComicCraft</a></p>
</body>
</html>
"""
    )


@app.get("/favicon.ico")
async def favicon():
    return JSONResponse(status_code=204, content=None)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host="127.0.0.1",
        port=8000,
        reload=True,
    )
