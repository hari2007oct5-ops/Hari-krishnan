# ComicCraft - Ready-to-Run Demo

## Windows

Open PowerShell in this folder and run:

    python -m venv .venv
    .venv\Scripts\Activate.ps1
    python -m pip install --upgrade pip
    pip install -r requirements.txt
    python -m uvicorn app.main:app --reload

Then open http://127.0.0.1:8000

This package runs in demo mode and does not require Gemini or Hugging Face API keys.
